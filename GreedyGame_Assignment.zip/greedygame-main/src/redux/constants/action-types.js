export const ActionTypes={
    SET_COLUMNS:"SET_COLUMNS",
};